//
//  main.c
//  day10
//
//  Created by tarena on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#include <stdio.h>
#include <string.h>

int main(int argc, const char * argv[])
{
    char str[5][10] = {"aaa", "bbb", "ccc", "ddd", "eee"};
    str[0][0] = 'A';
    for (int i = 0; i < 5; i++)
    {
        printf("%s\n", str[i]);
    }
    
    char* str1[5] = {"aaa", "bbb", "ccc", "ddd", "eee"};
    //*str1[0] = 'A';
    
    
    char name[3][20];
    for (int i = 0; i < 3; i++)
    {
        printf("请输入第%d个人的名字：", i + 1);
        scanf("%s", name[i]);
    }
    strcpy(name[0], "zhaoliu");
    for (int i = 0; i < 3; i++)
    {
        printf("%s\n", name[i]);
    }
    
    
    return 0;
}

//
//  02——输入一个姓名,判断是否是五虎上将.c
//  day10
//
//  Created by tarena on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#include <stdio.h>

int main()
{
    char name[20];
    printf("请输入一个名字：");
    scanf("%s", name);
    
    char* tiger[5] = {"GuanYu", "ZhangFei", "ZhaoYun", "MaChao", "HuangZhong"};
    int i;
    for (i = 0; i < 5; i++)
    {
        if (strcmp(name, tiger[i]) == 0)
        {
            printf("%s是五虎上将之一\n", name);
            break;
        }
    }
    if (5 == i)
    {
        printf("%s不是五虎上将之一\n", name);
    }
    
    
    return 0;
}
//
//  03_宏指令.c
//  day10
//
//  Created by tarena on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#include <stdio.h>
#include <stdbool.h>

#define SIZE 20
#define 布尔 bool
#define 真 true
#define 假 false
#define PI 3.14

int main()
{
    double area;
    area = PI * 5 * 5;
    area = PI * 3 * 3;
    
    布尔 r;
    r = 真;
    r = 假;
    
    int a[SIZE];
    for (int i = 0; i < SIZE; i++)
    {
        scanf("%d", a + i);
    }
    int b = 10;
    int max = a[0];
    for (int i = 1; i < SIZE; i++)
    {
        if (max < a[i])
        {
            max = a[i];
        }
    }
    for (int i = 0; i < SIZE; i++)
    {
        printf("%d ", a[i]);
    }
    printf("\n");
    
    return 0;
}
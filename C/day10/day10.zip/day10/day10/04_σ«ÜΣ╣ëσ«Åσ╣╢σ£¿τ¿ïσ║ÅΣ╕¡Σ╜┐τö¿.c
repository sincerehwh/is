//
//  04_定义宏并在程序中使用.c
//  day10
//
//  Created by tarena on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

//定义一个10个元素的数组，每个元素是一个0~99之间的随机值，求分别用函数最大值、最小值、和、平均数。
#define SIZE 10

int maxValue(int* data, int size)
{
    int max = data[0];
    for (int i = 1; i < size; i++)
    {
        if (max < data[i])
        {
            max = data[i];
        }
    }
    return max;
}

int minValue(int* data, int size)
{
    int min = data[0];
    for (int i = 1; i < 10; i++)
    {
        if (min > data[i])
        {
            min = data[i];
        }
    }
    return min;
}

int sumValue(int* data, int size)
{
    int sum = 0;
    for (int i = 0; i < 10; i++)
    {
        sum += data[i];
    }
    return sum;
}

double aveValue(int* data, int size)
{
    return sumValue(data, size) * 1.0 / size;
}

int main()
{
    srand((unsigned)time(0));
    
    int a[SIZE];
    for (int i = 0; i < SIZE; i ++)
    {
        a[i] = rand() % 100;
    }
    
    printf("max=%d\n", maxValue(a, SIZE));
    printf("min=%d\n", minValue(a, SIZE));
    printf("sum=%d\n", sumValue(a, SIZE));
    printf("ave=%g\n", aveValue(a, SIZE));
    
    return 0;
}
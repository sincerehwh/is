//
//  05_宏函数.c
//  day10
//
//  Created by tarena on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#include <stdio.h>

#define MIN(x, y) ((x) < (y) ? (x) : (y))
#define IS_ODD(x) ((x) % 2 != 0)
#define LOWER(ch) ((ch) >= 'A' && (ch) <= 'Z' ? (ch) - 'A' + 'a' : (ch))
#define PRINT(x, y) printf(#x"=%d,"#y"=%d\n", x, y)

int main()
{
    printf("%d\n", MIN(3, 5));
    double a = 3.14;
    double b = 2.68;
    printf("%g\n", MIN(a, b));
    
    int c  = 5;
    ;//从键盘输入c
    if (IS_ODD(c))
    {
        printf("是奇数\n");
    }
    else
    {
        printf("不是\n");
    }
    
    printf("%c\n", LOWER('C'));
    
    int x = 5;
    int y = 10;
    PRINT(x, y);
    int d = 6;
    int e = 7;
    PRINT(d, e);
    
    return 0;
}
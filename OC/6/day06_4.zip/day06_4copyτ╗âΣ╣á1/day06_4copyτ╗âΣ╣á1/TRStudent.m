//
//  TRStudent.m
//  day06_4copy练习1
//
//  Created by tarena on 15/9/23.
//  Copyright (c) 2015年 tarena. All rights reserved.
//

#import "TRStudent.h"

@implementation TRStudent
//-(void)setBook:(TRBook *)book
//{
//    self.book = [book copy];
//}
@end
